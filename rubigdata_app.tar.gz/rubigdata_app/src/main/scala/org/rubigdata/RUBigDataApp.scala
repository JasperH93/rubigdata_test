package org.rubigdata

import nl.surfsara.warcutils.WarcInputFormat
import org.jwat.warc.{WarcConstants, WarcRecord}
import org.apache.hadoop.io.LongWritable;
import org.apache.commons.lang.StringUtils;

import org.apache.spark.SparkContext
import org.apache.spark.SparkContext._
import org.apache.spark.SparkConf

import java.io.IOException;
import org.jsoup.Jsoup;

import java.io.InputStreamReader;

object RUBigDataApp {
  def main(args: Array[String]) {
    val fnm = "rubigdata-test.txt"
    val conf = new SparkConf().setAppName("RUBigDataApp")
    val sc = new SparkContext(conf)
//Loading in files
    val stopwordsf = sc.textFile("stopwords.txt")
    val warcfile = "/data/public/common-crawl/crawl-data/CC-MAIN-2016-07/segments/*/warc" 
    val warcf = sc.newAPIHadoopFile(
               warcfile,
               classOf[WarcInputFormat],               // InputFormat
               classOf[LongWritable],                  // Key
               classOf[WarcRecord]                     // Value
       )
//Old App code
    val data = sc.textFile(fnm, 2).cache()
    val numAs = data.filter(line => line.contains("a")).count()
    val numEs = data.filter(line => line.contains("e")).count()
    println("Lines with a: %s, Lines with e: %s".format(numAs, numEs))
//Defining functions
  def wikiSearch(str: String): Boolean = {
       str.startsWith("https://en.wikipedia.org") || str.startsWith("http://en.wikipedia.org")
  }

  def notCategory(str:String):Boolean = {
    !str.startsWith("Category:")
  }

  def getContent(record: WarcRecord):String = {
    val cLen = record.header.contentLength.toInt
    //val cStream = record.getPayload.getInputStreamComplete()
    val cStream = record.getPayload.getInputStream()
    val content = new java.io.ByteArrayOutputStream();
    val buf = new Array[Byte](cLen)
    var nRead = cStream.read(buf)
    while (nRead != -1) {
      content.write(buf, 0, nRead)
      nRead = cStream.read(buf)
    }
    cStream.close()
    content.toString("UTF-8");
  }

  def HTML2Txt(content: String) = {
    try {
      Jsoup.parse(content).text().replaceAll("[\\r\\n]+", " ")
    }
    catch {
      case e: Exception => throw new IOException("Caught exception processing input row ", e)
    }
  }

  }
}
